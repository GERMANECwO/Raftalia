import telebot
from telebot import types
from info import Raftalia

TOKEN = '6436229396:AAETecZbrkuiv_-vWuAlPdnXsl09Xhv_Cxc'
bot = telebot.TeleBot(TOKEN)

Raftalia_health = 100


@bot.message_handler(commands=["start"])
def start_(message):
    bot.send_message(message.chat.id, f"Запуск успешен!\n{message.from_user.first_name}, Приветствую! Я квест-бот!\n"
                                      f"/help - для информации!")


@bot.message_handler(commands=["help"])
def help_answer(message):
    bot.send_message(message.chat.id, f"Я квест-бот. на данный я могу предложить только 1 квест\n"
                                      f"мои правила вполне просты, много не тыкаем.\nЕсли вылезает ошибка, пишем мне "
                                      f"- \n/links - ссылки куда можно писать мне, чтобы сообщить об ошибке,\n"
                                      f"...или просто сказать спасибо\n"
                                      f"Чтобы начать - /start_game")


@bot.message_handler(commands=["links"])
def handle_links(message):
    bot.reply_to(message, "вот мои ссылки для связи:\n"
                          "ВК - https://vk.com/fxsstd\n"
                          "Тelegram - https://t.me/AlexLse\n")


@bot.message_handler(commands=['start_game'])
def start_game(message):
    markup_question = types.InlineKeyboardMarkup()
    answer1 = types.InlineKeyboardButton('ДА!', callback_data='Yes')
    answer2 = types.InlineKeyboardButton('Нет', callback_data='No')
    markup_question.add(answer1, answer2)
    bot.send_message(message.chat.id, "Вы готовы начать квест?", reply_markup=markup_question)


@bot.callback_query_handler(func=lambda call: True)
def handle_start_game(call):
    if call.data == 'Yes':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Зайти в хижину', callback_data='path1')
        itembtn2 = types.InlineKeyboardButton('Действовать с осторожностью', callback_data='path2')
        itembtn3 = types.InlineKeyboardButton('Не стоит тревожить тех, кто находится в ней..', callback_data='path3')
        markup.add(itembtn1)
        markup.add(itembtn2)
        markup.add(itembtn3)
        bot.send_message(call.message.chat.id, f"Небольшая предыстория.\n{Raftalia}\n\nСделайте свой выбор.\n"
                                               f"1. Вы можете ворваться в эту давно заброшенную хижину\n"
                                               f"2. Разведать вокруг её, и заглянуть в окна\n"
                                               f"3. не испытывать судьбы и пройти мимо"
                                               f"Что нужно сделать...? ", reply_markup=markup)

    elif call.data == 'No':
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "Если захотите пройти, то напишите снова /start_game !")

    global Raftalia_health

    # выбор локаций
    if call.data == "path1":
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Действие 1', callback_data='action1')
        itembtn2 = types.InlineKeyboardButton('Действие 2', callback_data='action2')
        markup.add(itembtn1, itembtn2)
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text="Вы выбрали путь 1. Что дальше?", reply_markup=markup)
    elif call.data == "path2":
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Действие 3', callback_data='action3')
        itembtn2 = types.InlineKeyboardButton('Действие 4', callback_data='action4')
        markup.add(itembtn1, itembtn2)
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text="Вы выбрали путь 2. Что дальше?", reply_markup=markup)
    # путь номер 3
    elif call.data == "path3":
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Пора возвращаться домой...', callback_data='path3_1')
        markup.add(itembtn1)
        result_photo = "https://imgur.com/a/Jbr2Wsq"
        caption_text = "Лучше я не буду тревожить хозяинов... - сказала Рафталия и развернувшись," \
                       " начинает уходить от этой хижины"
        bot.send_photo(call.message.chat.id, result_photo, caption=caption_text, reply_markup=markup)

    elif call.data == "action1":
        bot.send_message(call.message.chat.id, "Вы выбрали действие 1. Конец.")
    elif call.data == "action2":
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Следующий выбор', callback_data='next_choice')
        markup.add(itembtn1)
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text="Вы выбрали действие 2. Что дальше?", reply_markup=markup)
    elif call.data == "action3":
        bot.send_message(call.message.chat.id, "Вы выбрали действие 3. Конец.")
    elif call.data == "action4":
        markup = types.InlineKeyboardMarkup()
        itembtn1 = types.InlineKeyboardButton('Следующий выбор', callback_data='next_choice')
        markup.add(itembtn1)
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text="Вы выбрали действие 4. Что дальше?", reply_markup=markup)

        # действие 5 - нейтральная   концовка
    elif call.data == "path3_1":
        media = types.InputMediaPhoto(media="https://imgur.com/a/6IWg6e2", caption="Может это судьба "
                                                                                   "оберегла меня от опасности "
                                                                                   "внутри?\nДумала Рафталия,"
                                                                                   " будучи в безопасности... живой и здоровой.\n"
                                                                                   "Спасибо за прохождение! Концовка - нейтральная.\nВы не нашли ответов,"
                                                                                   " но остались живы..")
        bot.edit_message_media(chat_id=call.message.chat.id, message_id=call.message.message_id, media=media)

    elif call.data == "next_choice":
        bot.send_message(call.message.chat.id, "Это следующий выбор. Конец.")


bot.polling()
